#define BRANCH "InspIRCd-2.0"
#define VERSION "InspIRCd-2.0.24"
#define REVISION "0"
#define SYSTEM "FreeBSD asher 11.1-BETA3"
